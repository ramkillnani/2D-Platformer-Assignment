﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Controller : MonoBehaviour
{
    private Rigidbody2D rb2d;
    private float moveInput; //players move input
    private float speed = 10f; //characters move speed

    private float topScore = 0.0f;
    public Text scoreText; //displays the score
    
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>(); //pulls the rigidbody component
    }
    void Update()
    {
        if(rb2d.velocity.y > 0 && transform.position.y >topScore)
        {
            topScore = transform.position.y;
        }
        scoreText.text = "Score:" + Mathf.Round(topScore).ToString();

        if (rb2d.velocity.y < -50)
        {
            SceneManager.LoadScene("Gameover");
        }
    }
    void FixedUpdate()
    {
        moveInput = Input.GetAxis("Horizontal");
        rb2d.velocity = new Vector2(moveInput * speed, rb2d.velocity.y);
    }
}

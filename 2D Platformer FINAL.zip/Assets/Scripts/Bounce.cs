﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bounce : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision) //when the player hits the platform
    {
        if(collision.gameObject.GetComponent<Rigidbody2D>().velocity.y <= 0) //when the player hits the platform with a velocity of < 0
        {
            collision.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector3.up * 700f); //sets the players jump vertically by the amount set
        }
    }
}
